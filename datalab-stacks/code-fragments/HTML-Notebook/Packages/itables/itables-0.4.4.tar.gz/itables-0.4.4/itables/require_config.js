if (typeof require !== 'undefined')
    require.config({
        paths: {
            jquery: 'https://code.jquery.com/jquery-3.5.1.min',
            datatables: 'https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min',
        }
    });
